﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Myntra.Models;
using System.Configuration;

namespace Myntra
{
    public partial class Forgot : Form
    {
        string connStr = ConfigurationManager.ConnectionStrings["myntradb"].ConnectionString;
        string email;
        CredentialsLogic ob = new CredentialsLogic();
        public Forgot()
        {
            InitializeComponent();
        }
        public Forgot(string email)
        {
            InitializeComponent();
            this.email = email;
        }

        private void btnsub_Click(object sender, EventArgs e)
        {
            
            bool exist = ob.isExist(txtemail.Text);
            if (exist == true)
            {
                panel2.Visible = true;

                SqlConnection conn = new SqlConnection(connStr);
                string sql = "select SecurityQuestion from Customers where EMAILID='" + txtemail.Text + "'";
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        reader.Read();
                        labelques.Text = reader["SecurityQuestion"].ToString();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                MessageBox.Show("No account with this email exist");
                panel2.Visible = false;

            }
        }

        private void Forgot_Load(object sender, EventArgs e)
        {
            panel2.Visible = false;
            txtemail.Text = email;
            panel3.Visible = false;
        }

        private void btnsub1_Click(object sender, EventArgs e)
        {
            string str=ob.pulldata(txtemail.Text);
            if (str == txtans.Text)
            {
                panel3.Visible = true;
            }
            else
                MessageBox.Show("Wrong answer","Security Question",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            
               
        }

        private void btnrp_Click(object sender, EventArgs e)
        {
            if (txtnp.Text != string.Empty && txtrnp.Text != string.Empty)
            {
                if (txtnp.Text == txtrnp.Text)
                {
                    ob.update(txtemail.Text, txtnp.Text);
                }
                else
                    MessageBox.Show("Password doesnot match", "Password Reset", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
            }
            else
                MessageBox.Show("enter password");
        }

        private void btnbck_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            l.Show();
            this.Hide();
        }
    }
}
