﻿namespace Myntra
{
    partial class Checkout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Checkout));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnconfirm = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblta = new System.Windows.Forms.Label();
            this.lblamount = new System.Windows.Forms.Label();
            this.lblpay = new System.Windows.Forms.Button();
            this.btnbck = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(121, 78);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
            // 
            // btnconfirm
            // 
            this.btnconfirm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnconfirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnconfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnconfirm.ForeColor = System.Drawing.Color.Black;
            this.btnconfirm.Location = new System.Drawing.Point(770, 135);
            this.btnconfirm.Name = "btnconfirm";
            this.btnconfirm.Size = new System.Drawing.Size(188, 40);
            this.btnconfirm.TabIndex = 23;
            this.btnconfirm.Text = "Confirm ?";
            this.btnconfirm.UseVisualStyleBackColor = false;
            this.btnconfirm.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblpay);
            this.panel1.Controls.Add(this.lblamount);
            this.panel1.Controls.Add(this.lblta);
            this.panel1.Location = new System.Drawing.Point(848, 207);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(293, 194);
            this.panel1.TabIndex = 24;
            // 
            // lblta
            // 
            this.lblta.BackColor = System.Drawing.Color.LightBlue;
            this.lblta.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblta.Location = new System.Drawing.Point(12, 28);
            this.lblta.Name = "lblta";
            this.lblta.Size = new System.Drawing.Size(148, 60);
            this.lblta.TabIndex = 2;
            this.lblta.Text = "Total Amount :";
            this.lblta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblamount
            // 
            this.lblamount.BackColor = System.Drawing.Color.LightBlue;
            this.lblamount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblamount.Location = new System.Drawing.Point(155, 29);
            this.lblamount.Name = "lblamount";
            this.lblamount.Size = new System.Drawing.Size(121, 60);
            this.lblamount.TabIndex = 3;
            this.lblamount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblpay
            // 
            this.lblpay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.lblpay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblpay.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpay.ForeColor = System.Drawing.Color.Black;
            this.lblpay.Location = new System.Drawing.Point(62, 123);
            this.lblpay.Name = "lblpay";
            this.lblpay.Size = new System.Drawing.Size(188, 40);
            this.lblpay.TabIndex = 25;
            this.lblpay.Text = "Pay";
            this.lblpay.UseVisualStyleBackColor = false;
            // 
            // btnbck
            // 
            this.btnbck.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnbck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnbck.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbck.ForeColor = System.Drawing.Color.Black;
            this.btnbck.Location = new System.Drawing.Point(987, 135);
            this.btnbck.Name = "btnbck";
            this.btnbck.Size = new System.Drawing.Size(188, 40);
            this.btnbck.TabIndex = 26;
            this.btnbck.Text = "Back";
            this.btnbck.UseVisualStyleBackColor = false;
            this.btnbck.Click += new System.EventHandler(this.btnbck_Click);
            // 
            // Checkout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(1241, 656);
            this.Controls.Add(this.btnbck);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnconfirm);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Checkout";
            this.Text = "Checkout";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Checkout_FormClosed);
            this.Load += new System.EventHandler(this.Checkout_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnconfirm;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblamount;
        private System.Windows.Forms.Label lblta;
        private System.Windows.Forms.Button lblpay;
        private System.Windows.Forms.Button btnbck;
    }
}