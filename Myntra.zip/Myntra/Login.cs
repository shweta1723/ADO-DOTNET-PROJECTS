﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Myntra.Models;

namespace Myntra
{
    public partial class Login : Form
    {
        CredentialsLogic ob = new CredentialsLogic();
        public Login()
        {
            InitializeComponent();
        }
        //login
        private void button1_Click(object sender, EventArgs e)
        {
            string user = txtun.Text;
            string pass = txtpass.Text;
            if (user == string.Empty) { MessageBox.Show("User Name cant be empty"); }
            else if(pass==string.Empty) { MessageBox.Show("password cant be empty"); }
            else
            {
                Customers cust = null;
                int isValid = ob.isvaliduser(user, pass, out cust);

                if (isValid == 0)
                    MessageBox.Show("Email doesnot exists, click sign up");
                else if (isValid == 1)
                {
                    MessageBox.Show("Email exists, Reenter the correct passwrd");
                    txtpass.Text = "";
                }
                else if (isValid == 2)
                {
                    MessageBox.Show("Login Successfull","Sign in",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    //MessageBox.Show(cust.ToString());
                    DashBoard db = new DashBoard(cust);
                    db.Show();
                    this.Hide();
                }
                else
                    MessageBox.Show("Problem in establishment connection");
            }
        }

        private void lnksignup_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string email = txtun.Text;
            Signup sp = new Signup(email);
            sp.Show();
            this.Hide();
        
        }

        private void linkforgot_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string email = txtun.Text;
            Forgot f = new Forgot(email);
            f.Show();
            this.Hide();
        }
    }
}
