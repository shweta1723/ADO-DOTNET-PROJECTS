﻿namespace Myntra
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.label1 = new System.Windows.Forms.Label();
            this.txtun = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.linkforgot = new System.Windows.Forms.LinkLabel();
            this.lnksignup = new System.Windows.Forms.LinkLabel();
            this.btnlgn = new System.Windows.Forms.Button();
            this.txtpass = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "User Name";
            // 
            // txtun
            // 
            this.txtun.Location = new System.Drawing.Point(149, 31);
            this.txtun.Name = "txtun";
            this.txtun.Size = new System.Drawing.Size(166, 22);
            this.txtun.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.linkforgot);
            this.panel1.Controls.Add(this.lnksignup);
            this.panel1.Controls.Add(this.btnlgn);
            this.panel1.Controls.Add(this.txtpass);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtun);
            this.panel1.Location = new System.Drawing.Point(222, 205);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(558, 354);
            this.panel1.TabIndex = 2;
            // 
            // linkforgot
            // 
            this.linkforgot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.linkforgot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkforgot.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.linkforgot.LinkColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.linkforgot.Location = new System.Drawing.Point(150, 198);
            this.linkforgot.Name = "linkforgot";
            this.linkforgot.Size = new System.Drawing.Size(172, 37);
            this.linkforgot.TabIndex = 6;
            this.linkforgot.TabStop = true;
            this.linkforgot.Text = "Forgot Password ?";
            this.linkforgot.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.linkforgot.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkforgot_LinkClicked);
            // 
            // lnksignup
            // 
            this.lnksignup.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.lnksignup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnksignup.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lnksignup.LinkColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lnksignup.Location = new System.Drawing.Point(172, 250);
            this.lnksignup.Name = "lnksignup";
            this.lnksignup.Size = new System.Drawing.Size(119, 37);
            this.lnksignup.TabIndex = 5;
            this.lnksignup.TabStop = true;
            this.lnksignup.Text = "Sign Up";
            this.lnksignup.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lnksignup.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnksignup_LinkClicked);
            // 
            // btnlgn
            // 
            this.btnlgn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnlgn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnlgn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlgn.ForeColor = System.Drawing.Color.Black;
            this.btnlgn.Location = new System.Drawing.Point(149, 147);
            this.btnlgn.Name = "btnlgn";
            this.btnlgn.Size = new System.Drawing.Size(166, 37);
            this.btnlgn.TabIndex = 4;
            this.btnlgn.Text = "Login";
            this.btnlgn.UseVisualStyleBackColor = false;
            this.btnlgn.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtpass
            // 
            this.txtpass.Location = new System.Drawing.Point(149, 93);
            this.txtpass.Name = "txtpass";
            this.txtpass.Size = new System.Drawing.Size(166, 22);
            this.txtpass.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "Password";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.LightBlue;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(363, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(152, 129);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(893, 599);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Login";
            this.Text = "Login";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtun;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.LinkLabel lnksignup;
        private System.Windows.Forms.Button btnlgn;
        private System.Windows.Forms.TextBox txtpass;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.LinkLabel linkforgot;
    }
}

