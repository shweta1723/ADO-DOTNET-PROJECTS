﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Myntra.Models;

namespace Myntra
{
    public partial class DashBoard : Form
    {
        Customers c = new Customers();
        Cart_logic cl = new Cart_logic();
        int txt;
        public DashBoard()
        {
            InitializeComponent();
        }
        public DashBoard(Customers c)
        {
            InitializeComponent();
            this.c = c;
        }
        private void DashBoard_Load(object sender, EventArgs e)
        {
            lblweltxt.Text = "Welcome " + c.Fullname;
            txt = cl.cart_count();
            if (txt != 0)
                lblc.Text = txt.ToString();
        }
        //ethnic navigation
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            All_Ethnic eth = new All_Ethnic(11,c);
            eth.Show();
            this.Hide();
        }

        private void DashBoard_FormClosed(object sender, FormClosedEventArgs e)
        {
            cart_reset ob = new cart_reset();
            ob.cartreset();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Cart c = new Cart();
            c.Show();
            this.Hide();
        }
    }
}
