﻿namespace Myntra
{
    partial class Product_desc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Product_desc));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblprodname = new System.Windows.Forms.Label();
            this.lblproddetails = new System.Windows.Forms.Label();
            this.lblprodprice = new System.Windows.Forms.Label();
            this.btnbck = new System.Windows.Forms.Button();
            this.btnadd = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblcart = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.lblc = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(89, 84);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(252, 324);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lblprodname
            // 
            this.lblprodname.AutoSize = true;
            this.lblprodname.Location = new System.Drawing.Point(445, 120);
            this.lblprodname.Name = "lblprodname";
            this.lblprodname.Size = new System.Drawing.Size(46, 17);
            this.lblprodname.TabIndex = 1;
            this.lblprodname.Text = "label1";
            // 
            // lblproddetails
            // 
            this.lblproddetails.AutoSize = true;
            this.lblproddetails.Location = new System.Drawing.Point(445, 186);
            this.lblproddetails.Name = "lblproddetails";
            this.lblproddetails.Size = new System.Drawing.Size(46, 17);
            this.lblproddetails.TabIndex = 2;
            this.lblproddetails.Text = "label2";
            // 
            // lblprodprice
            // 
            this.lblprodprice.AutoSize = true;
            this.lblprodprice.Location = new System.Drawing.Point(445, 255);
            this.lblprodprice.Name = "lblprodprice";
            this.lblprodprice.Size = new System.Drawing.Size(46, 17);
            this.lblprodprice.TabIndex = 3;
            this.lblprodprice.Text = "label2";
            // 
            // btnbck
            // 
            this.btnbck.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnbck.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnbck.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbck.ForeColor = System.Drawing.Color.Black;
            this.btnbck.Location = new System.Drawing.Point(34, 529);
            this.btnbck.Name = "btnbck";
            this.btnbck.Size = new System.Drawing.Size(98, 31);
            this.btnbck.TabIndex = 8;
            this.btnbck.Text = "Back";
            this.btnbck.UseVisualStyleBackColor = false;
            this.btnbck.Click += new System.EventHandler(this.btnbck_Click);
            // 
            // btnadd
            // 
            this.btnadd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnadd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnadd.ForeColor = System.Drawing.Color.Black;
            this.btnadd.Location = new System.Drawing.Point(448, 345);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(122, 37);
            this.btnadd.TabIndex = 9;
            this.btnadd.Text = "Add to Cart";
            this.btnadd.UseVisualStyleBackColor = false;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // label1
            // 
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.Location = new System.Drawing.Point(14, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 60);
            this.label1.TabIndex = 10;
            this.label1.Text = "Pay on Delivery";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label2
            // 
            this.label2.Image = ((System.Drawing.Image)(resources.GetObject("label2.Image")));
            this.label2.Location = new System.Drawing.Point(126, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 60);
            this.label2.TabIndex = 11;
            this.label2.Text = "30 Days return";
            this.label2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label3
            // 
            this.label3.Image = ((System.Drawing.Image)(resources.GetObject("label3.Image")));
            this.label3.Location = new System.Drawing.Point(231, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 60);
            this.label3.TabIndex = 12;
            this.label3.Text = "Delivery";
            this.label3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label4
            // 
            this.label4.Image = ((System.Drawing.Image)(resources.GetObject("label4.Image")));
            this.label4.Location = new System.Drawing.Point(344, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(135, 73);
            this.label4.TabIndex = 13;
            this.label4.Text = "No contact Delivery";
            this.label4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(386, 405);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(523, 116);
            this.panel1.TabIndex = 14;
            // 
            // lblcart
            // 
            this.lblcart.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcart.Location = new System.Drawing.Point(915, 37);
            this.lblcart.Name = "lblcart";
            this.lblcart.Size = new System.Drawing.Size(29, 27);
            this.lblcart.TabIndex = 15;
            this.lblcart.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // linkLabel1
            // 
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.Image = ((System.Drawing.Image)(resources.GetObject("linkLabel1.Image")));
            this.linkLabel1.LinkColor = System.Drawing.Color.Black;
            this.linkLabel1.Location = new System.Drawing.Point(896, 27);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(115, 77);
            this.linkLabel1.TabIndex = 16;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Cart";
            this.linkLabel1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // lblc
            // 
            this.lblc.BackColor = System.Drawing.Color.Transparent;
            this.lblc.Location = new System.Drawing.Point(950, 37);
            this.lblc.Name = "lblc";
            this.lblc.Size = new System.Drawing.Size(35, 26);
            this.lblc.TabIndex = 17;
            this.lblc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
           
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(117, 78);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 20;
            this.pictureBox2.TabStop = false;
            // 
            // Product_desc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.ClientSize = new System.Drawing.Size(1189, 659);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.lblc);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.lblcart);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.btnbck);
            this.Controls.Add(this.lblprodprice);
            this.Controls.Add(this.lblproddetails);
            this.Controls.Add(this.lblprodname);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Product_desc";
            this.Text = "Product description";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Product_desc_FormClosed);
            this.Load += new System.EventHandler(this.Product_desc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblprodname;
        private System.Windows.Forms.Label lblproddetails;
        private System.Windows.Forms.Label lblprodprice;
        private System.Windows.Forms.Button btnbck;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblcart;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label lblc;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}