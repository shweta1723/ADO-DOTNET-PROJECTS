﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Myntra.Models;
using System.Configuration;
using System.Data.SqlClient;

namespace Myntra
{
    public partial class Product_desc : Form
    {
        Cart_logic cl = new Cart_logic();
        Products prod = new Products();
        Customers c = new Customers();
        List<cart_store> ls = new List<cart_store>();
        int txt;
        string path;
        
        public Product_desc()
        {
            InitializeComponent();

        }
        
        public Product_desc(Products p,string path)
        {
            InitializeComponent();
            prod = p;
            this.path = path;
            
            
        }

        private void Product_desc_Load(object sender, EventArgs e)
        {
            txt = cl.cart_count();
            if (txt != 0)
                lblc.Text = txt.ToString();
            pictureBox1.Image = Image.FromFile(path + prod.IMGPATH);
            lblproddetails.Text = prod.PDESCIPTION;
            lblprodname.Text = prod.PNAME;
            lblprodprice.Text = prod.PRICE.ToString();   
        }

        private void btnbck_Click(object sender, EventArgs e)
        {
            All_Ethnic ae = new All_Ethnic(11,c);
            ae.Show();
            this.Hide();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Cart c = new Cart();
            c.Show();
            this.Hide();
            
        }

        private void Product_desc_FormClosed(object sender, FormClosedEventArgs e)
        {
            cart_reset ob = new cart_reset();
            ob.cartreset();
        }

       
        private void btnadd_Click(object sender, EventArgs e)
        {

            cl.CARTID_NO();
            string number = (cl.MyNumber).ToString();
            string connStr = ConfigurationManager.ConnectionStrings["myntradb"].ConnectionString;
            SqlConnection conn = new SqlConnection(connStr);
            string sql = "insert into Cart values('" + prod.IMGPATH + "','" + prod.PDESCIPTION + "','" + prod.PNAME + "','" + prod.PRICE + "','" + path + "','"+number+"')";

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                MessageBox.Show("ADDED TO CART","CART",MessageBoxButtons.OK,MessageBoxIcon.Information);
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            txt = cl.cart_count();
            if (txt != 0)
                lblc.Text = txt.ToString();

        }

       
    }
}
