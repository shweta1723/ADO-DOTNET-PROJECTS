﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Myntra.Models;
using System.Data.SqlClient;
using System.Configuration;

namespace Myntra
{
    public partial class Cart : Form
    {

        
        List<cart_store> ls = null;
        Cart_logic ob = new Cart_logic();
        
        public Cart()
        {
            InitializeComponent();
        }
        public Cart(int count)
        {
            InitializeComponent();
            
        }

        private void Cart_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
            ls = ob.getall_cartdata();
            if (ls.Count == 0)
            {
                panel1.Visible = true;
                button1.Visible = false;
                panel2.Visible = false;
            }
            else
            {

                DirectoryInfo di = new DirectoryInfo(Application.StartupPath);
                string path = di.Parent.Parent.FullName + @"\images\";

                int x = 50, y = 90;
                for (int i = 0; i < ls.Count; i++)
                {
                    if (i != 0 && i % 1 == 0)
                    {
                        x = 50;
                        y = y + 150;
                    }


                    PictureBox p = new PictureBox();
                    p.Name = "pic" + i.ToString();

                    p.Location = new System.Drawing.Point(x, y);
                    p.Size = new Size(150, 100);
                    p.Click += message;
                    p.Image = Image.FromFile(path + ls[i].IMAGEPATH);
                    p.SizeMode = PictureBoxSizeMode.StretchImage;
                    //p.Click += message;


                    Label l = new Label();
                    l.Text = ls[i].cart_display();
                    l.Size = new Size(500, 90);
                    l.Location = new System.Drawing.Point(x + 200, y + 25);
                    x += 190;

                    Button b = new Button();
                    b.Name = ls[i].Cartid;

                    b.Location = new Point(x + 300, y + 20);
                    b.Text = "DELETE ITEM";
                    b.Size = new Size(100, 30);
                    b.BackColor = Color.Transparent;
                    b.Click += message1;

                    this.Controls.Add(b);
                    this.Controls.Add(p);
                    this.Controls.Add(l);

                }
            }

        }
        private void message(object sender, EventArgs e)
        {
            PictureBox p = (PictureBox)sender;
            int id = Convert.ToInt32(p.Name.Substring(3,5));

            
        }
        private void message1(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            int id1 = Convert.ToInt32(b.Name);
            
            string connStr = ConfigurationManager.ConnectionStrings["myntradb"].ConnectionString;

            SqlConnection conn = new SqlConnection(connStr);
            string sql = "delete  from cart where CARTID= " + id1.ToString();
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            Cart c = new Cart();
            c.Show();
            this.Hide();
        }

        private void Cart_FormClosed(object sender, FormClosedEventArgs e)
        {
            cart_reset ob = new cart_reset();
            ob.cartreset();
        }

        private void btnbck_Click(object sender, EventArgs e)
        {
            DashBoard db = new DashBoard();
            db.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DashBoard db = new DashBoard();
            db.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Checkout c = new Checkout();
            c.Show();
            this.Hide();
        }
    }
}
