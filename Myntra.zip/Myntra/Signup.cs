﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Myntra.Models;

namespace Myntra
{
    public partial class Signup : Form
    {
        CredentialsLogic ob = new CredentialsLogic();
        string email;
        public Signup()
        {
            InitializeComponent();
        }
        public Signup(string email)
        {
            InitializeComponent();
            this.email = email;
        }

        private void Signup_Load(object sender, EventArgs e)
        {
            txtemail.Text = email;
            bool exist = ob.isExist(txtemail.Text);
            if (exist == true)
                MessageBox.Show("Email already exist", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            this.Hide();
            l.Show();
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool exist = ob.isExist(txtemail.Text);
            if (exist == true)
            {
                MessageBox.Show("Email already exist", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txtemail.Text = "";
            }
            else
            {
                Customers c = new Customers();
                c.Email = txtemail.Text;
                c.Password = txtpass.Text;
                c.Fullname = txtfn.Text;
                c.Phone = txtphone.Text;
                c.Address = txtaddress.Text;
                c.SecurityQuestion = txtsq.Text;
                c.SecurityAnswer = txtans.Text;

                //MessageBox.Show(c.ToString());
                ob.register(c);

            }
        }
    }
}
