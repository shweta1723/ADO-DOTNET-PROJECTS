﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Myntra.Models;
using System.IO;
using System.Data.SqlClient;
using System.Configuration;

namespace Myntra
{
    public partial class Checkout : Form
    {

        List<cart_store> ls = null;
        Cart_logic ob = new Cart_logic();

        public Checkout()
        {
            InitializeComponent();
        }

        private void Checkout_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
            DirectoryInfo di = new DirectoryInfo(Application.StartupPath);
            string path = di.Parent.Parent.FullName + @"\images\";
            ls = ob.getall_cartdata();
            int x = 50, y = 90;
            for (int i = 0; i < ls.Count; i++)
            {
                if (i != 0 && i % 1 == 0)
                {
                    x = 50;
                    y = y + 150;
                }


                PictureBox p = new PictureBox();
                p.Name = "pic" + i.ToString();

                p.Location = new System.Drawing.Point(x, y);
                p.Size = new Size(150, 100);
               // p.Click += message;
                p.Image = Image.FromFile(path + ls[i].IMAGEPATH);
                p.SizeMode = PictureBoxSizeMode.StretchImage;
                //p.Click += message;

                Label l = new Label();
                l.Text = ls[i].cart_display();
                l.Size = new Size(500, 90);
                l.Location = new System.Drawing.Point(x + 200, y + 25);
                x += 190;

                
                this.Controls.Add(p);
                this.Controls.Add(l);
            }
        }

       

        private void button1_Click_1(object sender, EventArgs e)
        {
            panel1.Visible = true;
            Cart_logic cl = new Cart_logic();
            List<string> ls = cl.getprice();
            int total = 0;
            for (int i = 0; i < ls.Count; i++)
            {
                total = total + int.Parse(ls[i]);
            }
            lblamount.Text = total.ToString();
        }

        private void Checkout_FormClosed(object sender, FormClosedEventArgs e)
        {
            cart_reset ob = new cart_reset();
            ob.cartreset();
        }

        private void btnbck_Click(object sender, EventArgs e)
        {
            DashBoard db = new DashBoard();
            db.Show();
            this.Hide();
        }
    }
}
