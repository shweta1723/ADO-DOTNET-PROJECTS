﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Myntra.Models;
using System.IO;
using System.Configuration;
using System.Data.SqlClient;

namespace Myntra
{
    public partial class All_Ethnic : Form
    {
        
        int catid;       
        prod_logic ob = new prod_logic();
        Customers c = new Customers();
        Cart_logic cl = new Cart_logic();
        string path;int count = 0;
        List<Products> lp = null;
        public All_Ethnic()
        {
            InitializeComponent();
        }
        public All_Ethnic(int id, Customers c)
        {
            InitializeComponent();
            this.catid = id;
            this.c = c;
            
            
        }
        

        public All_Ethnic(int id)
        {
            InitializeComponent();
            this.catid = id;  
        }
        
        private void All_Ethnic_Load(object sender, EventArgs e)
        {

            int txt = cl.cart_count();
            if (txt != 0)
                lblc.Text = txt.ToString();

            lp = ob.getall_productdata(catid);
            DirectoryInfo di = new DirectoryInfo(Application.StartupPath);
            path = di.Parent.Parent.FullName + @"\images\";
            
            int x = 50, y = 60;
            for(int i = 0; i < lp.Count; i++)
            {
                if (i!=0 && i % 4 == 0)
                {
                    x = 50;
                    y = y + 220;
                }

                PictureBox p = new PictureBox();
                p.Name = "pic" + i.ToString();             
                p.Click += message;
                p.Location = new System.Drawing.Point(x, y);
                p.Size = new Size(150, 100);
                p.Image = Image.FromFile(path + lp[i].IMGPATH);
                p.SizeMode = PictureBoxSizeMode.StretchImage;
                Label l = new Label();
                l.Text = lp[i].prod_display();
                l.Size = new Size(150, 90);
                l.Location = new System.Drawing.Point(x, y + 100);
                this.Controls.Add(p);
                this.Controls.Add(l);
                x += 190;
                
            }

        }
        private void message(object sender,EventArgs e)
        {
            PictureBox p = (PictureBox)sender;            
            int id = Convert.ToInt32(p.Name.Substring(3));            
            
            //MessageBox.Show(id.ToString());
            Product_desc pd = new Product_desc(lp[id],path);
            pd.Show();
            this.Hide();
        }

        private void btnbck_Click(object sender, EventArgs e)
        {
            DashBoard db = new DashBoard(c);
            db.Show();
            this.Hide();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Cart c = new Cart();
            c.Show();
            this.Hide();
            
           
        }

        private void All_Ethnic_FormClosed(object sender, FormClosedEventArgs e)
        {
            cart_reset ob = new cart_reset();
            ob.cartreset();
        }

        private void All_Ethnic_FormClosed_1(object sender, FormClosedEventArgs e)
        {
            cart_reset ob = new cart_reset();
            ob.cartreset();
        }
    }
}
