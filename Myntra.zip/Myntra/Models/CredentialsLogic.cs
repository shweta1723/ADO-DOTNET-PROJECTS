﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Myntra.Models
{
    class CredentialsLogic
    {
        string connStr = ConfigurationManager.ConnectionStrings["myntradb"].ConnectionString;
        
        public int isvaliduser(string usr,string pass,out Customers c)
        {
            int valid = 0;
            c = new Customers();
            SqlConnection conn = new SqlConnection(connStr);
            string sql = "select * from Customers where Emailid='" + usr +"'";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    valid = 1;
                    if (reader.GetValue(1).ToString() == pass)
                    {
                        valid = 2;
                        
                        c.Email = reader.GetValue(0).ToString();
                        c.Password = reader.GetValue(1).ToString();
                        c.Fullname = reader.GetValue(2).ToString();
                        c.Phone = reader.GetValue(3).ToString();
                        c.Address= reader.GetValue(4).ToString();
                        c.SecurityQuestion = reader.GetValue(5).ToString();
                        c.SecurityAnswer = reader.GetValue(6).ToString();
                        
                    }
                }
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
                valid = -1;
            }
            finally
            {
                conn.Close();
            }

            return valid;
        }
        public bool isExist(string email)
        {
            bool value=false;
            SqlConnection conn = new SqlConnection(connStr);
            string sql = "select * from Customers where Emailid='" + email + "'";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    if (reader.GetValue(0).ToString() == email)
                    {
                        value=true;
                    }
                    else
                        value=false;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);

            }
            finally
            {
                conn.Close();
            }
            return value;
        }
        public void register(Customers c)
        {
            SqlConnection conn = new SqlConnection(connStr);
            try
            {
                conn.Open();
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into Customers values('" + c.Email + "','" + c.Password + "','" + c.Fullname + "','" + c.Phone + "','" + c.Address + "','" + c.SecurityQuestion + "','" + c.SecurityAnswer +  "')";
                cmd.ExecuteNonQuery();
                MessageBox.Show("Registered", "Registartion", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);

            }
            finally
            {
                conn.Close();
            }
        }
        public string pulldata(string email)
        {
            CredentialsLogic ob = new CredentialsLogic();
            string str="";
            bool exist = ob.isExist(email);
            if (exist == true)
            {
                SqlConnection conn = new SqlConnection(connStr);
                string sql = "select SecurityAnswer from Customers where EMAILID='" + email + "'";
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        reader.Read();
                        str = reader["SecurityAnswer"].ToString();
                        
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
                finally
                {
                    conn.Close();
                }
            }
            return str;
        }
        public void update(string email,string password)
        {
            
            SqlConnection conn = new SqlConnection(connStr);
            string sql = "update Customers set PASSWORD= '" + password + "' where EMAILID='" + email + "' ";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Reset Successfully","Reset Password",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
                conn.Close();
            }

        }
        
    }
}
