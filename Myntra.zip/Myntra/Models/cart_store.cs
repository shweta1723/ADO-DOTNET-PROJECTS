﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Myntra.Models
{
    public class cart_store
    {
        public string IMAGEPATH { get; set; }
        public string desc { get; set; }
        public string Name { get; set; }
        public string price { get; set; }
        public string path { get; set; }
        public string Cartid { get; set; }

        public string cart_display()
        {
            string data = "";

            data += " NAME =" + Name.ToString() + " \n DESCRIPTION =" + desc.ToString() + " \n PRICE =" + price.ToString();
            

            return data;
        }

    }
}
