﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Myntra.Models
{
    class cart_reset
    {
        public void cartreset()
        {
            string connStr = ConfigurationManager.ConnectionStrings["myntradb"].ConnectionString;
            SqlConnection conn = new SqlConnection(connStr);
            string sql = "TRUNCATE TABLE Cart";

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
               

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
