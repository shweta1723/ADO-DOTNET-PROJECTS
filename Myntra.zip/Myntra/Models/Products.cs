﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Myntra.Models
{
    public class Products
    {
        public int PID { get; set; }
        public string PNAME { get; set; }
        public string PDESCIPTION { get; set; }
        public float PRICE { get; set; }
        public int CID { get; set; }
        public string IMGPATH { get; set; }


        public override string ToString()
        {
            string data = "";
            data += "PID =" + PID.ToString();
            data += "\n PNAME =" + PNAME.ToString();
            data += "\n PDESCRIPTION =" + PDESCIPTION.ToString();
            data += "\n PRICE =" + PRICE.ToString();
            data += "\n CID =" + CID.ToString();
            data += "\n IMGPATH =" + IMGPATH.ToString();

            return data;
        }
        public string prod_display()
        {
            string data = "";
           
            data += "\n PNAME =" + PNAME.ToString();
            data += "\n PDESCRIPTION =" + PDESCIPTION.ToString();
            data += "\n PRICE =" + PRICE.ToString();
   
            return data;
        }
    }
}
