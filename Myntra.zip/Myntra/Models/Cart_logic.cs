﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Myntra.Models
{
    public class Cart_logic
    {
        public Random a = new Random();
        public int MyNumber = 0;
        public List<int> randomList = new List<int>();
        public void CARTID_NO()
        {
            MyNumber = a.Next(1000, 10000);
            while (randomList.Contains(MyNumber))
                MyNumber = a.Next(1000, 10000);
        }

        public List<cart_store> getall_cartdata()
        {
            string connStr = ConfigurationManager.ConnectionStrings["myntradb"].ConnectionString;
            List<cart_store> ls = new List<cart_store>();
            SqlConnection conn = new SqlConnection(connStr);
            string sql = "select * from cart ";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    cart_store cs = new cart_store();
                    cs.IMAGEPATH = reader.GetValue(0).ToString();
                    cs.desc = reader.GetValue(1).ToString();
                    cs.Name = reader.GetValue(2).ToString();
                    cs.price = reader.GetValue(3).ToString();
                    cs.path = reader.GetValue(4).ToString();
                    cs.Cartid =  reader.GetValue(5).ToString();
                    ls.Add(cs);
                    
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return ls;
        }
        public int cart_count()
        {
            int count = 0;
            string connStr = ConfigurationManager.ConnectionStrings["myntradb"].ConnectionString;
            SqlConnection conn = new SqlConnection(connStr);
            string sql = "select COUNT(*) as cartno from cart ";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                //int count = 0;
                if (reader.Read())
                {
                    count = reader.GetInt32(0);
                }
                
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return count;
        }
        public List<string>  getprice()
        {
            string price="";
            List<string> ls = new List<string>();
            string connStr = ConfigurationManager.ConnectionStrings["myntradb"].ConnectionString;
            SqlConnection conn = new SqlConnection(connStr);
            string sql = "select price from cart ";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                
                    while (reader.Read())
                    {
                        price = reader.GetValue(0).ToString();
                        ls.Add(price);
                    }
                
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return ls;
        }
    }
}
