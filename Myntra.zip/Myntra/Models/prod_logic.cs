﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Myntra.Models
{
    class prod_logic
    {
        string connStr = ConfigurationManager.ConnectionStrings["myntradb"].ConnectionString;

        public List<Products> getall_productdata(int cid)
        {
            List<Products> lp = new List<Products>();
            SqlConnection conn = new SqlConnection(connStr);
            string sql = "select * from products where CID= " + cid.ToString();
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Products p = new Products();
                    p.PID = Convert.ToInt32(reader.GetValue(0).ToString());
                    p.PNAME = reader.GetValue(1).ToString();
                    p.PDESCIPTION = reader.GetValue(2).ToString();
                    p.PRICE = float.Parse(reader.GetValue(3).ToString());
                    p.CID= Convert.ToInt32(reader.GetValue(4).ToString());
                    p.IMGPATH= reader.GetValue(5).ToString();
                    lp.Add(p);
                }
            }
            catch(Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return lp;
        }
    }
}
